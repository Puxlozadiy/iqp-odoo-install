* Synconics Technologies Pvt. Ltd.
* `Synconics Technologies Pvt. Ltd. <https://www.synconics.com>`__:
