## Module <easy_language_selector>

#### 15.07.2023
#### Version 16.0.1.0.0
##### ADD
- Initial Commit for Easy Language Selector

#### 19.09.2023
#### Version 16.0.1.0.1
##### UPDT
- Bug Fix : Navbar translation issue.